# RKEEL
RKEEL: Using Keel in R code

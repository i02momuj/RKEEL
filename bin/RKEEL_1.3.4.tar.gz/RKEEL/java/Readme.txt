The source files of the KEEL .jars could be obtained downloading KEEL at http://keel.es/.
